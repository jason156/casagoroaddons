# -*- coding: utf-8 -*-

from . import product_price_wiz
from . import product_pricelist
from . import product_template
from . import res_currency