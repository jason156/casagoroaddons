# -*- coding: utf-8 -*-
from . import product_template
from . import res_config_settings
from . import product_category
from . import pos_payment
from . import purchase_order