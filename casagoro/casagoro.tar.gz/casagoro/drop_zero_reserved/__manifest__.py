# -*- coding: utf-8 -*-
{
    'name': "zero reserves cancel",

    'summary': """
        Cancel moves with reserves """,

    'description': """
        Long description of module's purpose
    """,

    'author': "Cancel moves with reserves",
    'website': "http://www.hormigag.ar",

    'category': 'stock',
    'version': '13.0.0.1',

    'depends': ['stock'],

    'data': [
        'views/views.xml',
    ],
}
