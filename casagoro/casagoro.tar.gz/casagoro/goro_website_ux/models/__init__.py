# -*- coding: utf-8 -*-

from . import brand
from . import product_template