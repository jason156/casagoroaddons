# -*- coding: utf-8 -*-
{
    'name': "goro website ux",

    'summary': """
        UX website""",

    'description': """
        UX website
    """,

    'author': "filoquin",
    'website': "http://www.casagoro.com.ar",

    'category': 'website',
    'version': '13.0.1.0.1',

    'depends': ['website_sale', 'droggol_theme_common'],

    'data': [

    ],
}
