# -*- coding: utf-8 -*-
#################################################################################
#
#   Copyright (c) 2016-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#   See LICENSE file for full copyright and licensing details.
#   License URL : <https://store.webkul.com/license.html/>
#
#################################################################################

from odoo import api, fields, models
from odoo.tools import float_is_zero, float_compare
import logging
_logger = logging.getLogger(__name__)

class AccountMove(models.Model):
    _inherit = 'account.move'

    partial_payment_remark = fields.Char(string="Remark")

class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    def _reconcile_lines(self, debit_moves, credit_moves, field):
        # ************pos partial payment compatibility******************
        if self._context.get('coming_from_pos'):
            (debit_moves + credit_moves).read([field])
            to_create = []
            cash_basis = debit_moves and debit_moves[0].account_id.internal_type in ('receivable', 'payable') or False
            cash_basis_percentage_before_rec = {}
            dc_vals ={}
            while (debit_moves and credit_moves):
                debit_move = debit_moves[0]
                credit_move = credit_moves[0]
                company_currency = debit_move.company_id.currency_id
                temp_amount_residual = min(debit_move.amount_residual, -credit_move.amount_residual)
                temp_amount_residual_currency = min(debit_move.amount_residual_currency, -credit_move.amount_residual_currency)
                dc_vals[(debit_move.id, credit_move.id)] = (debit_move, credit_move, temp_amount_residual_currency)
                amount_reconcile = min(debit_move[field], -credit_move[field])
                debit_moves -= debit_move
                credit_moves -= credit_move
                currency = False
                amount_reconcile_currency = 0
                if field == 'amount_residual_currency':
                    currency = credit_move.currency_id.id
                    amount_reconcile_currency = temp_amount_residual_currency
                    amount_reconcile = temp_amount_residual

                if cash_basis:
                    tmp_set = debit_move | credit_move
                    cash_basis_percentage_before_rec.update(tmp_set._get_matched_percentage())

                to_create.append({
                    'debit_move_id': debit_move.id,
                    'credit_move_id': credit_move.id,
                    'amount': amount_reconcile,
                    'amount_currency': amount_reconcile_currency,
                    'currency_id': currency,
                })
            cash_basis_subjected = []
            part_rec = self.env['account.partial.reconcile']
            for partial_rec_dict in to_create:
                debit_move, credit_move, amount_residual_currency = dc_vals[partial_rec_dict['debit_move_id'], partial_rec_dict['credit_move_id']]
                if not amount_residual_currency and debit_move.currency_id and credit_move.currency_id:
                    part_rec.create(partial_rec_dict)
                else:
                    cash_basis_subjected.append(partial_rec_dict)

            for after_rec_dict in cash_basis_subjected:
                new_rec = part_rec.create(after_rec_dict)
                if cash_basis and not (
                        new_rec.debit_move_id.move_id == new_rec.credit_move_id.move_id.reversed_entry_id
                        or
                        new_rec.credit_move_id.move_id == new_rec.debit_move_id.move_id.reversed_entry_id
                ):
                    new_rec.create_tax_cash_basis_entry(cash_basis_percentage_before_rec)

            return debit_moves+credit_moves
        # **************************************************************
        else:
            res = super(AccountMoveLine,self)._reconcile_lines(debit_moves, credit_moves, field)
            return res


    @api.depends('debit', 'credit', 'account_id', 'amount_currency', 'currency_id', 'matched_debit_ids', 'matched_credit_ids', 'matched_debit_ids.amount', 'matched_credit_ids.amount', 'move_id.state', 'company_id')
    def _amount_residual(self):
        """ Computes the residual amount of a move line from a reconcilable account in the company currency and the line's currency.
            This amount will be 0 for fully reconciled lines or lines from a non-reconcilable account, the original line amount
            for unreconciled lines, and something in-between for partially reconciled lines.
        """

        if self._context.get('created_from_pos'):
            # line.reconciled = False
            for line in self:
                if not line.account_id.reconcile and line.account_id.internal_type != 'liquidity':
                    line.reconciled = False
                    line.amount_residual = 0
                    line.amount_residual_currency = 0
                    continue
                #amounts in the partial reconcile table aren't signed, so we need to use abs()
                amount = abs(line.debit - line.credit)
                amount_residual_currency = abs(line.amount_currency) or 0.0
                sign = 1 if (line.debit - line.credit) > 0 else -1
                if not line.debit and not line.credit and line.amount_currency and line.currency_id:
                    #residual for exchange rate entries
                    sign = 1 if float_compare(line.amount_currency, 0, precision_rounding=line.currency_id.rounding) == 1 else -1

                for partial_line in (line.matched_debit_ids + line.matched_credit_ids):
                    # If line is a credit (sign = -1) we:
                    #  - subtract matched_debit_ids (partial_line.credit_move_id == line)
                    #  - add matched_credit_ids (partial_line.credit_move_id != line)
                    # If line is a debit (sign = 1), do the opposite.
                    sign_partial_line = sign if partial_line.credit_move_id == line else (-1 * sign)

                    amount += sign_partial_line * partial_line.amount
                    #getting the date of the matched item to compute the amount_residual in currency
                    if line.currency_id and line.amount_currency:
                        if partial_line.currency_id and partial_line.currency_id == line.currency_id:
                            amount_residual_currency += sign_partial_line * partial_line.amount_currency
                        else:
                            if line.balance and line.amount_currency:
                                rate = line.amount_currency / line.balance
                            else:
                                date = partial_line.credit_move_id.date if partial_line.debit_move_id == line else partial_line.debit_move_id.date
                                rate = line.currency_id.with_context(date=date).rate
                            amount_residual_currency += sign_partial_line * line.currency_id.round(partial_line.amount * rate)

                line.reconciled = False

                line.amount_residual = line.move_id.company_id.currency_id.round(amount * sign) if line.move_id.company_id else amount * sign
                line.amount_residual_currency = line.currency_id and line.currency_id.round(amount_residual_currency * sign) or 0.0
        else:
            super(AccountMoveLine,self)._amount_residual()


    def auto_reconcile_lines(self):
        if self._context.get('coming_from_pos'):
            debit_moves = self.filtered(lambda r: r.debit != 0 or r.amount_currency > 0)
            new_moves = self.filtered(lambda r: r.credit == 0 and r.debit == 0 or r.amount_currency < 0)
            actual_credit_moves = self.filtered(lambda r: r.credit != 0 or r.amount_currency < 0)
            unsorted_credit_moves = actual_credit_moves + new_moves
            credit_moves = unsorted_credit_moves.sorted()
            debit_moves = debit_moves.sorted(key=lambda a: (a.date_maturity or a.date, a.currency_id))
            credit_moves = credit_moves.sorted(key=lambda a: (a.date_maturity or a.date, a.currency_id))
            # Compute on which field reconciliation should be based upon:
            if self[0].account_id.currency_id and self[0].account_id.currency_id != self[0].account_id.company_id.currency_id:
                field = 'amount_residual_currency'
            else:
                field = 'amount_residual'
            #if all lines share the same currency, use amount_residual_currency to avoid currency rounding error
            if self[0].currency_id and all([x.amount_currency and x.currency_id == self[0].currency_id for x in self]):
                field = 'amount_residual_currency'
            # Reconcile lines
            ret = self._reconcile_lines(debit_moves, credit_moves, field)
            return ret
        else:
            res = super(AccountMoveLine,self).auto_reconcile_lines()
            return res


class AccountMove(models.Model):
    _inherit = "account.move"

    def _compute_amount(self):
        super(AccountMove, self)._compute_amount()

        # ***************Code For Partially Paid Orders*********************
        currencies = set()
        pos_invoices = self.filtered(lambda i: i.type in ['out_invoice', 'out_refund'] and i.pos_order_ids)
        invoice_ids = [move.id for move in pos_invoices if move.id and move.is_invoice(include_receipts=True)]
        if invoice_ids:
            self._cr.execute(
                '''
                    SELECT move.id
                    FROM account_move move
                    JOIN account_move_line line ON line.move_id = move.id
                    JOIN account_partial_reconcile part ON part.debit_move_id = line.id OR part.credit_move_id = line.id
                    JOIN account_move_line rec_line ON
                        (rec_line.id = part.credit_move_id AND line.id = part.debit_move_id)
                        OR
                        (rec_line.id = part.debit_move_id AND line.id = part.credit_move_id)
                    JOIN account_payment payment ON payment.id = rec_line.payment_id
                    JOIN account_journal journal ON journal.id = rec_line.journal_id
                    WHERE payment.state IN ('posted', 'sent')
                    AND journal.post_at = 'bank_rec'
                    AND move.id IN %s
                ''', [tuple(invoice_ids)]
            )
            in_payment_set = set(res[0] for res in self._cr.fetchall())
        else:
            in_payment_set = {}
        for invoice in pos_invoices:
            
            for line in invoice.line_ids:
                if line.currency_id:
                    currencies.add(line.currency_id)
            orders = invoice.pos_order_ids
            for order in orders:
                currency = len(currencies) == 1 and currencies.pop() or order.account_move.company_id.currency_id
                is_paid = currency and currency.is_zero(order.account_move.amount_residual) or not order.account_move.amount_residual
                if order.is_partially_paid:
                    if order.account_move.state == 'posted' and is_paid:
                        if order.account_move.id in in_payment_set:
                            order.account_move.invoice_payment_state = 'in_payment'
                        else:
                            order.account_move.invoice_payment_state = 'paid'
                    else:
                        order.account_move.invoice_payment_state = 'not_paid'
        # ********************************************************************************