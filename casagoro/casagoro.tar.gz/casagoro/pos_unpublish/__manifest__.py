# -*- coding: utf-8 -*-
{
    'name': "pos unpublish",

    'summary': """
        Asiste a la despublicacion multiple de productos""",

    'description': """
        Asiste a la despublicacion multiple de productos
    """,

    'author': "filoqui",
    'website': "http://www.hormigag.com",

    'category': 'pos',
    'version': '13.0.0.1',

    'depends': ['point_of_sale', 'stock', 'purchase'],

    'data': [
        'views/views.xml',
    ],
}
